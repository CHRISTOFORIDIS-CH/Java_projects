package p19188;

public class Main {
    public static void main(String ars[]){
        long startTime = System.nanoTime();
        int sum = 0;
        String [] letters  = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
        String words = "";
        human h_1 = new human();
        System.out.println(h_1.getAge());
        System.out.println(h_1.getName());
        for(int i = 0 ;i <= 100;i++){ //εβαλα μεχρι 100 γιατι με Integer.MaxValue δεν τελειωνε ποτε στο laptop μου
            sum += 1;   // ενα απλο αθροισμα
            for(String s:letters){
                words += s; // απο πινακα γεμιζει με γραμματα του αλφαβητου
            }

            }
        System.out.println(words);
        h_1 = new student(); // casting
        h_1.Ispeak();
        student s_1 = new student();
        System.out.println(s_1.getAm());
        s_1.askProfessor();
        long stopTime = System.nanoTime();
        long duration = stopTime - startTime;
        System.out.println("Duration:"+duration);
      /* int n1 = 34845200;
        int n2 = 31400000;
        int n3 = 27514601;
        int n4 = 27790400;
        int n5 = 32716800;
        double mo = n1 + n2 + n3 + n4 + n5;
        System.out.println(mo); = 1.54267001E8 // το ετρεξα 5 φορες και βγαινει αυτος ο μεσος ορος
       */
        }
    }

