package p19188;

public class student extends human { //για το casting
    private String am = "p19188";
void askProfessor(){
    System.out.println("Please give me good grades");
}
    public String getAm() {
        return am;
    }
}
