package p19188;

public class human { // για το casting
    private int age = 18;
    private String name = "Charis";
    void Ispeak(){
        System.out.println("I am a Human");
    }
    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }
}
