package P19188;

public class unipi_assistant_professor extends unipi_professor{
    private String assist_am;

}
