package P19188;

public class unipi_professor extends human{
    private String prof_am;
    private String subject;

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setProf_am(String prof_am) {
        this.prof_am = prof_am;
    }
    void Celebrate_2(){
        System.out.println("I FINALLY BECAME A PROFESSOR");
    }
}
