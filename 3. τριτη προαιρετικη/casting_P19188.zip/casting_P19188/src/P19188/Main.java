package P19188;   //project για casting απο ανθρωπος -> επικουρος καθηγητης -> καθηγητης με βαση κριτηριων κ.λ.π

import java.util.Scanner;

public class Main {
    public static void main(String args[]){
    human new_human = new human();
        if(new_human.getAge() >= 50){
           new_human = new unipi_assistant_professor();
           new_human.Celebrate(); // υλοποειται αφου η unipi_assistant_professor κανει extend την human
        }
        int assistant_professor_years = 0;
        for(int i = 0 ;i >= 100;i++){ // παροδος των χρονων πρεπει να ειανι τουλαχιστον 10 χρονια επικουρος για να διοριστει ως κανονικο καθηγητης
            assistant_professor_years++;
            if (assistant_professor_years == 10){
                break;
            }
        }
        new_human = new unipi_professor(); // μετα το περας των χρονων γινεται καθηγητης
    }
}
