package P19188;

public class human {
    private String name = "charis";
    private int age = 60;

    public int getAge() {
        return age;
    }
    void Celebrate(){
        System.out.println("I AM AN UNIPI ASSISTANT PROFESSOR");
    }
}
