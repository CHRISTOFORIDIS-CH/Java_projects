package unipi.p19188;

public class student {
    private String name;

    public String getGrade() {
        return grade;
    }

    private String grade;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
    @Override
    public String toString() {
        return "Student Name: " + this.getName() +
                ", Student Grade: " + this.getGrade();
    }

}
