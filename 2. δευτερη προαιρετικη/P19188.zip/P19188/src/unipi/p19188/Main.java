package unipi.p19188;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    static public void main(String args[]) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("menu"));
            for (String line; (line = br.readLine()) != null; ) {
                System.out.print(line + "\n");
            }
            br.close();
        } catch (IOException e) {
            System.out.println("There is no file");
        }

        List<student> List_1 = new ArrayList<>();
        try {
            Scanner answ = new Scanner(System.in);
            int answer = answ.nextInt();

            while (answer != 5) {
                if (answer == 1) {
                    for (student s : List_1) {
                        System.out.println(s); // 1oς τροπος
                    }
                } else if (answer == 2) {
                    student n_s = new student(); // new_student
                    Scanner b_1 = new Scanner(System.in); // το b_1 σαν βοηθητικο αντικειμενο για να κανω σκαν
                    System.out.println("give the name of the student");
                    String n = b_1.nextLine();
                    n_s.setName(n);
                    System.out.println("give the grade of the student");
                    String g = b_1.nextLine();
                    n_s.setGrade(g);
                    List_1.add(n_s);
                    System.out.println("The student is saved");
                } else if (answer == 3) {
                    /* αν ειχα απλα strings και οχι objects της student
                     *System.out.println("give the name of the student you want to delete");
                     *String want_n = want_name.nextLine();
                     *if (List_1.contains(want_name)) {
                     *   List_1.remove(List_1.indexOf(want_name));
                     *         System.out.println("the student deleted successfully");
                     *    }
                     */
                    System.out.println("give the name of the student you want to delete");
                    Scanner b_4 = new Scanner(System.in) ;
                    String s_name_2 = b_4.nextLine();
                    search_student obj = new search_student();
                    for(student i:List_1){
                    if(obj.isStudentInList(List_1,s_name_2) == true) {
                        //δεν βρηκα καποιο τροπο να κανει delete object να κανει delete
                    }
                    }

                } else if (answer == 4) {
                    /* αν ειχα απλα strings και οχι object της student
                    System.out.println("give the name of the student you want to search");
                    Scanner b_3 = new Scanner(System.in);
                    String want_name = b_3.nextLine();
                    if (List_1.contains(want_name)) {
                        System.out.println("The searched students information are:");
                        System.out.println(List_1.get(List_1.indexOf(want_name)));
                    } else {
                        System.out.println("No such student exists");
                    }
                     */
                    search_student s_name = new search_student();
                    System.out.println("give the name of the student you want to search");
                    Scanner b_3 = new Scanner(System.in);
                    String name = b_3.nextLine();
                    boolean result = false;
                    if (s_name.isStudentInList(List_1,name) == true) {
                        System.out.println("The student exist");
                    } else {
                        System.out.println("The student doesnt exist");
                    }
                }

                    if (answer == 5) {
                        System.out.println("The list is:");
                        ListIterator<student> b_2 = List_1.listIterator();
                        while (b_2.hasNext()) {
                            System.out.println(b_2.next());
                        }
                        System.out.println("Thanks fo using the app");
                    }
                    System.out.println("If you want to continue give an other option,else give 5 to exit ");
                    answer = answ.nextInt();
                }
            }

     catch (InputMismatchException a) {
            System.out.println("give a valid input");
        }


    }
}
