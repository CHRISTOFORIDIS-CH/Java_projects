package unipi.p19188;

import java.util.Collection;

public class search_student {
    public static boolean isStudentInList(Collection<student> List_1, String name) {
        for (student i : List_1) {
            if (i != null && i.getName().equals(name)) {
              boolean result = true;
                break;
            } else {
                boolean result =  false;
            }

        }
        return result; //σε μενα εδω πεταγε error cannot resolve the symbol αλλα δεν βρισκω κατι λαθος
        }
    }

