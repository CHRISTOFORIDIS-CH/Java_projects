package Ternary_Operator_slide_139;

public class TernaryOperatorExample {
    public static void main(String args[]){
        int a =10;
        int b =20;
        int c = (a > b)? 30:40; // if(a>b){int c = 30}else{int c = 40}
        System.out.println(c);
    }
    /*
    *Σαν μια γρηγορη if then else αλλα δεν συνισταται αφου ειναι αρκετα δυσαναγνωστη
     */
}
