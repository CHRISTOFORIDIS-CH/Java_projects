package Casting_slide_184;

public class car implements KTEO{
    String coniditon; // good or bad
    @Override
    public boolean conductCheckUp(){
        if(coniditon.equals("good")){
            return true;
        }
        else{
            return false;
        }
    }
}
