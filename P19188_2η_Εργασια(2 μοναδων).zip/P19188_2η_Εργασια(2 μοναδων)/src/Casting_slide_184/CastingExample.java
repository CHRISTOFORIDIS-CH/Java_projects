package Casting_slide_184;
//εστω οτι ειμαστε σε ενα κτεο και κοιταει ποια αμαξια περνανε κανοντας τα drivable αν περνανε και non-drivable αν δεν περνανε
public class CastingExample {

}
interface KTEO{
    boolean conductCheckUp();
}