package Casting_slide_184;

public class undrivable extends car {
    String message = "I am not drivable";
}
