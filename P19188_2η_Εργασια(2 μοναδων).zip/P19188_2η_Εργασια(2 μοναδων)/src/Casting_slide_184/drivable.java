package Casting_slide_184;

public class drivable extends car {
   String message = "I am drivable";

}
