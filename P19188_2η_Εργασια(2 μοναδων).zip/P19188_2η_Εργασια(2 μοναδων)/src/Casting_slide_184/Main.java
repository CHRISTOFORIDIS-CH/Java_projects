package Casting_slide_184;

public class Main {
    public static void main(String args[]){
        car newCar = new car();
        newCar.coniditon = "good";
        if(newCar.conductCheckUp()){
            System.out.println(((drivable)newCar).message);
        }
        else{
            System.out.println(((undrivable)newCar).message);
        }
    }
}
