package Switch_Vs_If_slide_144;

public class SwitchVsIfExample {
    public static void main(String args){
        int a =2;
        //εστω οτι θελω να ελεγξω ποια τιμη εχει το α απο 1-5 και να το εμφανισω
        //με if θα ηταν:
        if(a == 1){
            System.out.println(a);
        }
        else if(a == 2){
            System.out.println(a);
        }
        else if(a == 3){
            System.out.println(a);
        }
        else if(a == 4){
            System.out.println(a);
        }
        else if(a == 5){
            System.out.println(a);
        }
        /*
        *προφανως ο παραπανω τροπος ειναι αργος και κοστοβορος και ισως θα ηταν καλυτερα να εχω μια if  σε καποιο loop(i <=5)
        * και να ελεγχω με το i,γι'αυτο σε τετοια σεναρια χρησιμευει καλυτερα η switch
         */
        //με switch
        switch (a){
            case 1:
                break;
            case 2:
                break;
            case 3:
                System.out.println(a);
                break;
            case 4:
                break;
            case 5:
                break;
        }
        /*
        *δεν χρειαζεται να γραφω ολοκληρη την ισοτητα καθε φορα επισης η switch μπορει να δεχτει
        * οποιοδηποτε τυπο δηλαδη να πω switch(a) με case "charis" πρεπει να προσεξω ομως τα break;
        * γιατι αν δεν υπαρχουν τοτε με το που βρει ενα αληθες case εκτελει και ολα τα απο κατω του
         */
    }
}
