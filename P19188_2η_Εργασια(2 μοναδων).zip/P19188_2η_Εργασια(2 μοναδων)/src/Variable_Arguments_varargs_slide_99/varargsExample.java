package Variable_Arguments_varargs_slide_99;

public class varargsExample {
    public static void main(String[] args){
printFruits("Orange","Apple","Tomato");
    }
    public static void printFruits(/*int a,*/String... args){ // το τελευταιο να ειναι το args π.χ αν ειχα το α
        for(String s:args){
            System.out.println(s);
            //System.out.println(a);
        }
    }
    /*
    *δεν μπορω να βαλω δευτερο ορισμα args σε μια μεθοδο π.χ να πω printFruits(String...args,Integer...args)
    * επισης πρεπει να ειναι παντα το τελευταιο απο ολα τα ορισματα

     */
}
