package Instance_Of_Operator_slide_100;

public class Student extends Human{
    private int AM = 19188;
    public void IspeakStudent(){
        System.out.println("Hello I am a Student");
    }

    public int getAM() {
        return AM;
    }
}
