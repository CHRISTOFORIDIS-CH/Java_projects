package Instance_Of_Operator_slide_100;

public class Professor extends Human{
    private String subject = "Maths";
    public void IspeakProfessor(){
        System.out.println("Hello I am a Professor");
    }

    public String getSubject() {
        return subject;
    }
}
