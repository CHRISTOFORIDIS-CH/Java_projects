package Instance_Of_Operator_slide_100;

import Variable_Scope_slide_91.instanceExample;

public class Human {
    private int age = 19;
    private String Name ="Charis" ;
    public void Ispeak(){
        System.out.println("Hello I am a Human");
    }

    public String getName() {
        return Name;
    }

    public int getAge() {
        return age;
    }
}
