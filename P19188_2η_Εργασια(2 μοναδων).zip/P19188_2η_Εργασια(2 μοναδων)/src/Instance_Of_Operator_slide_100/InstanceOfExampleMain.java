package Instance_Of_Operator_slide_100;

public class InstanceOfExampleMain {
    public static void main(String args){
        Student Sobj = new Student();
        Professor Pobj = new Professor();
        Student[] Sarray ={Sobj};
        Professor[] Parray = {Pobj};
        findObjectStatus(Sarray);
        findObjectStatus(Parray);
    }
    public static <T> void findObjectStatus(T[] tArray){
        for(T element:tArray){
            if(element instanceof Human){ // ισχυει αφου κανουν και οι δυο implement
               if(element instanceof Student){
                   ((Student) element).Ispeak();
                   System.out.println(" And my afm is: "+((Student) element).getAM());
               }
               else if(element instanceof Professor){
                   ((Professor) element).Ispeak();
                   System.out.println("And my subject is: "+((Professor) element).getSubject());
               }

            }
        }
    }
    /*
    *Kοιταω τι ειδους ειναι τα αντικειμενα με τη βοηθεια του instance of εκτυπωνω τα αναλογα στοιχεια(το εκανα με generics σαν extra )
     */
}
