package Import_Usage_slide_46;

public class Example {
   public void printsmthing(){
        System.out.println("Hello");
    }
}
