package Vairables_slide_176;

public class Main {
    public static void main(String args){
        //μεσω της κλασσης του
        VairablesExample obj = new VairablesExample();
        obj.var1 = "Hello";
        obj.printVar();
//μεσω του interface(της ταξης γονιος κλπ)
        someActions[] prints = new someActions[2];
        prints[0] = new VairablesExample();
        prints[1] = new VariableExampleSubClass();
        for(someActions elemnts:prints){
            System.out.println(elemnts);
        }
    }
    /*
    *Ουσιαστικα μεσω του κοινου interface μπορω με anonymous objects να επικαλεστω την μεθοδο του interface
    * και μαζι με μια for each να φτιαξω ενα <<πινακα>> που εκτελει την μεθοδο για ολα τα anonymous object που
    * περιερχει
     */
}
