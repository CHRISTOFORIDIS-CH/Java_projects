package Vairables_slide_176;

public class VairablesExample implements someActions{
    String var1;
    @Override
   public void printVar(){
       System.out.println(var1);
   }
}
class VariableExampleSubClass extends VairablesExample implements  someActions{
    @Override
    public void printVar() {
        System.out.println(var1);
    }
}


interface someActions{
     void printVar();
}
