package AutoBoxing_Unboxing_slide_21;

public class Example {
    public static void main(String args[]) {
        //boxing int i1 to Integer i1
        Integer i1 = new Integer(10); //μου λεει και intelij οτι ειναι αχρειαστο boxing διαγραφοντας το Integer
        System.out.println(i1);
        //unboxing Integer a1 to int a2
        int i2 = i1;
        System.out.println(i2);
        //boxing char c1 to Character c1
        Character c1 = new Character('a'); // μου λεει και το intelej οτι ειναι ειναι αχρειαστο boxing διαγραφοντας το Character
        System.out.println(c1);
        //unboxing Character c1 to char c2
        char c2 = c1;
        System.out.println(c2);
    }
    /*
    *boxing ειναι μετατρεπω μια primitive type μεταβλητη στην αναλογη reference type της πχ int -> Integer ή char -> Character
    * ενω unboxing είναι το αντιθετο(πχ Integer -> int κλπ) εβαλα και τη main για να δειξω οτι οταν γινονται αυτες οι διαδικασιες
    * προφανως δεν χανεται καμοια τιμη.
     */
}
