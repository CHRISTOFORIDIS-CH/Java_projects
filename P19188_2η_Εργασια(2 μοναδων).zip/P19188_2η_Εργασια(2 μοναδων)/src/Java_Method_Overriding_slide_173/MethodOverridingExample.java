package Java_Method_Overriding_slide_173;

public class MethodOverridingExample {
    public static void main(String args[]){

    }
}
