package Java_Method_Overriding_slide_173;

public class SubClass extends SuperClass {
    @Override
    public int MethodToOverRide(int a, int b) {
        return super.MethodToOverRide(a, b);
    }
}
