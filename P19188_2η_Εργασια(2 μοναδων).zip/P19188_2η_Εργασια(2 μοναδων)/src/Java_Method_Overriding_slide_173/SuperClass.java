package Java_Method_Overriding_slide_173;

public class SuperClass {
    public  int MethodToOverRide(int a,int b){
        return a+b;
    };
}
