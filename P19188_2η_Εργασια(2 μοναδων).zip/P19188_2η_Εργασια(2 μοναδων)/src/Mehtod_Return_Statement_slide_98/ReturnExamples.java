package Mehtod_Return_Statement_slide_98;

public class ReturnExamples {
    public int ReturnInt(){
        return 1; // Οποιοδηποτε τυπο int,String κλπ θελει return Statement
    }
    public void RetrunNothing(){
        System.out.println("I don't return anything"); // αφου ειναι void δεν χρειαζεται το return
    }
    public String FindRightI(int var){
        for(int i= 0;i <= var;i++){
            if(i ==var){
                return "Right value";
            }
        }
        return "The i doesn't have the right value";
    }
    /*
    *Στο τελευταιο παραδειγμα παρατηρω οτι παρ ολο που εχω βαλει ενα return το intelij δεν ικανοποιειται με το return μεσα στο for
    * ,απ εναντιας οφηλω να βαλω ενα ακομα αφου το πρωτο δεν βρισκεται μονο μεσα σε for αλλα και σε if και η συνθηκη του if μπορει
    * να μην ικανοποιειται ποτε αν ομως ικανοποιηθει τερματιζεται η μεθοδος
     */
}
