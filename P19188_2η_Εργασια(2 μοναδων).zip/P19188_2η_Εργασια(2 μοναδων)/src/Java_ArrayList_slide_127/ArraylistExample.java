package Java_ArrayList_slide_127;

import Class_vs_Object_slide_5.Car;

import java.util.ArrayList;

public class ArraylistExample {
public static void main(String args[]){
    ArrayList<String> arrayList = new ArrayList();
    //Arraylist με ονοματα
    //εισαγωγη
    arrayList.add("Charis");
    arrayList.add("Maria");
    arrayList.add("Giorgos");
    //προσπελαση και εμφανηση με for each
    for( String s:arrayList){
        System.out.println(s);
    }
    //διαγραφη
    arrayList.remove("Charis");
    for( String s:arrayList){
        System.out.println(s);
    }
    //αλλαγη στοιχειου απο Maria σε Mariaaaa
    arrayList.set(0,"Mariaaaa");
    for( String s:arrayList){
        System.out.println(s);
    }
      }
}
