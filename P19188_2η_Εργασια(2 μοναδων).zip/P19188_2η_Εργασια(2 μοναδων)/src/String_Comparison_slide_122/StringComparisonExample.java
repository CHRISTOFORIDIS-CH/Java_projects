package String_Comparison_slide_122;

public class StringComparisonExample {
    public static void main(String args){
        //εστω δυο String με το ιδιο value
        String s1 = "Charis";
        String s2 = "Charis";
        //αν ελεγχξω με ==
        if(s1 == s2){
            System.out.println("s1 is equal to s2");
        }
        else{
            System.out.println("s1 is not equal to s2");
        }
        /*
        *Στην παραπανω περιπτωση θα παρατηρησουμε οτι ολα λειτουργουν οπως θα επρεπαι και βγαζουμε τα σωστα αποτελεσματα
        * δηλαδη <<s1 is equal to s2>>
         */
        //Εστω τωρα δυο νεα String παλι με το ιδιο value αλλα τωρα το ενα θα το δηλωσω με αλλο αλλα ισοδυναμο τροπο
        String s3 = "Charis";
        String s4 = new String("Charis");
        //αν ελεγζξω με το ==
        if(s3 == s4){
            System.out.println("s3 is equal to s4");
        }
        else{
            System.out.println("s3 is not equal to s4");
        }
        /*παρατηρω οτι μου βγαινει λαθος αποτελεσμα δηλαδη <<s3 is not equal to s4>>
        *Συνεπως για να ειμαι παντα καλημενος χρησιμοποιω την equals και ειναι
         */
        if(s3.equals(s4)){
            System.out.println("s3 is equal to s4");
        }
        else{
            System.out.println("s3 is not equal to s4");
        }
    }

}
