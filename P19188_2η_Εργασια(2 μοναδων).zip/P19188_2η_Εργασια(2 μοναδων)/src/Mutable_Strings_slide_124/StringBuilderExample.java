package Mutable_Strings_slide_124;

public class StringBuilderExample {
    public static void main(String args[]){
        String s1 = "charis";
        String s=null;
        StringBuilder sb = new StringBuilder();
        for (int i=0;i<1000000;i++){
            s+=" "+String.valueOf(i);
        }
        for (int i=0;i<1000000;i++){
            sb.append(" ");
            sb.append(i);
        }
        String result = sb.toString();

        s1.replace("ris","ra");
        System.out.println(s1);
    }
    /*
    *Χρησημοποιησα το παραδειγμα απο την προαιρετικη που ειχα κανει τοτε για τα Strings
    * Ουστιαστικα χρησιμοποιειται για την διαχειρηση μεγαλων Strings
     */
}
