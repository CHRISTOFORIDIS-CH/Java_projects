package Static_Imports_Example_slide_53;

public class car_garage {
    public static int carsnNum = 20;
    public static void welcomeprint(){
        System.out.println("Welcome to our garage we currently have inside "+carsnNum+" cars");
    }
}
