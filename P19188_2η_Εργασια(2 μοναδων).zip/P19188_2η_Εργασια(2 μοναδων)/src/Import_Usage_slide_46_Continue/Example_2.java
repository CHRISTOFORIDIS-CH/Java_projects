package Import_Usage_slide_46_Continue;

//import Import_Usage_slide_46.Example;
public class Example_2 {
   /* public static void main(String args[]) {
        Example obj = new Example(); // αφου εκανα import μπορω να την χρησιμοποιησω απευθειας μονο με το ονομα της και ασ ειναι και σε αλλο package
        obj.printsmthing();
    }
    */
   /* public static void main(String args[]){
        Import_Usage_slide_46.Example obj = new Import_Usage_slide_46.Example(); //εδω αφου το import πλεον δεν υπαρχει θα πρεπει να χρησιμοποιησω το <<fully qualified name>>
        obj.printsmthing();
    }

    */
   /*εχω και τις δυο main σε σχολια γενικα αμα δεν βαλω import τοτε πρεπει να χρησιμοποιησω το <<μεγαλο>> ονομα,αφου αλλιως
   ο compiler δεν μπορει να καταλαβει σε ποια κλασση κλπ αναφερομαι
    */
}
