package Access_Modifiers_slide_66;

public class publicExample {
    public int a =10;
    public int b =5;
    public int sumNums2(){
        return a+b;
    }
}
