package Access_Modifiers_slide_66;

public class defaultExample {
    int a = 10;
    int b = 5;
    int sumNums(){
        return a+b;
    }
}
