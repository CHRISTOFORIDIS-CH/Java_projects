package Access_Modifiers_slide_66;

public class protectedExample {
    protected int a = 10;
    protected int b = 20;
    protected int sumNums3(){
        return a+b;
    }
}
