package Access_Modifiers_slide_66;

public class privateExample {
    private int a;
    private int b;

    public void setB(int b) {
        this.b = b;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public int getA() {
        return a;
    }
    private int sumMethod(){
        return a+b;
    }
    /*
    *οι private μεταβλητες εχουν εμβελεια μονο μεσα στην κλασση τους συνεπω για να τις χρησιμοποιησω
    * φτιαχνω setters και getters συγκεκριμενα εδω στη main θα εμφανιζω το αθροισμα τους αφου πρωτα τους
    * δοσω τιμες
     */
}
