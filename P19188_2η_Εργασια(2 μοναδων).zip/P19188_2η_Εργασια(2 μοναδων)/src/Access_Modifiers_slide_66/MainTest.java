package Access_Modifiers_slide_66;

public class MainTest {
    public static void main(){
        privateExample obj = new privateExample();
        obj.setA(10);
        obj.setB(5);
        //obj.a = 10; κατι τετοιο δεν μπορει να υποθει καθως η μεταβλητη α οντας private δεν αναγνωριζεται εκτος της κλασσης
        System.out.println(obj.getA()+obj.getB()); // οπως και πριν δεν μπορω να πω obj.a +obj.b για τους ιδιους λογους
        /*obj.sumMethod() ενω η διαδικασια της προσθεσης υπαρχει στην αλλη κλασση επισης δεν μπορει να γινει αφου και η μεθοδος ειναι private
        *και συνεπως δεν αναγνωριζεται
         */
        defaultExample obj2 = new defaultExample();
        System.out.println(obj2.a);
        System.out.println(obj2.b);
        System.out.println(obj2.sumNums());
        /*
        *αφου τα εχω δηλωσει default ισχυουν παντου εντος του πακετου που βρισκομαι(Access_Modifiers_slide_66)
        *αν προσπαθουσα να τα χρησιμοποιησω σε άλλο πακετο δεν θα μπορουσα
        * ουσιαστικα η dafault περιοριζει την εμβελεια εντος του ιδιου πακετου
         */
        publicExample obj3 = new publicExample();
        System.out.println(obj3.a);
        System.out.println(obj3.b);
        System.out.println(obj3.sumNums2());
        /*
        *εμπροκειμενου το public λειτουργει σαν το default η διαφορα ειναι οτι απο την στιγμη που τα δηλωσα public
        * μετα αν θελησω μπορω να τα χρησιμοποιήσω οπουδηποτε αρκει να ξερω να τα καλεσω με το αναλογο import
         */
        protectedExample obj4 =new  protectedExample();
        System.out.println(obj4.a);
        System.out.println(obj4.b);
        System.out.println(obj4.sumNums3());
         /*
         *το protected μπορει να χρησιμοποιηθει εδω περα γιατι ανηκουν οι κλασσεισ στο ιδιο πακετο γενικα
         * για να χρησιμοποιησω μια protected μεταβλητη ή μεθοδο θα πρεπει η κλασση μου να ειναι υποκλασση
         * αυτης που εχουν δηλωθει δηλαδη να την κανει extend
          */
    }

}
