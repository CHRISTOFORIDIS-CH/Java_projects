package Inheritance_slide_161;

public class Human {
    private int age;
    private String Name;
    public void Ispeak(){
        System.out.println("Hello I am a Human!!");
    }

    public void setName(String name) {
        Name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return Name;
    }

    public int getAge() {
        return age;
    }
}
