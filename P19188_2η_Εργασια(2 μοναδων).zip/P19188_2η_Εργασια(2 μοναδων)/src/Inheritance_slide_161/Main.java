package Inheritance_slide_161;

public class Main {
    public static void main(String args[]){
        Human Hobj = new Human();
        Hobj.setAge(19);
        Hobj.setName("Charis");
        Hobj.Ispeak();
        System.out.println("My age is "+Hobj.getAge()+"and my name is "+Hobj.getName());
        //o ανθρωπος εχει ονομα και ηλικια μετα γινεται μαθητης οποτε αποκτα και ΑΜ = Αριθμος Μητρωου
       Student Sobj = new Student();
        Sobj.setAge(19);
        Sobj.setName("Charis");
        Sobj.setAm(19188);
        Sobj.Istudy();
        System.out.println("My age is"+Sobj.getAge()+"and my name is "+Sobj.getName()+"and my AM is "+Sobj.getAm());
       //o μαθητης μετα απο διαβασμα καταφερνει να γινει και καθηγητης οποτε χανει το ΑΜ του αλλα αποκτα μαθημα να διδασκει
        Professor Pobj = new Professor();
        Pobj.setAge(19);
        Pobj.setName("Charis");
        Pobj.setSubject("Maths");
        Pobj.Iteach();
        System.out.println("My age is"+Pobj.getAge()+"and my name is "+Pobj.getName()+"and my subject is"+Pobj.getSubject());
    }
    /*
    *Αρα ο μαθητης και ο καθηγητης κληρωνομουν απο τον ανρθωπο και εχουν και οι δυο σιγουρα ονομα και ηλικια
    * αφου πανω απο ολα ειναι ανρθωποι παρ' ολα αυτα εχει και ο καθενας τα δικα του χαρακτηριστικα και ιδιοτητες
    * π.χ ο μαθητης διαβαζει ενω ο καθηγητης διδασκει ομως παραλληλα και οι δυο μπορουν να μιλησουν
     */
}
