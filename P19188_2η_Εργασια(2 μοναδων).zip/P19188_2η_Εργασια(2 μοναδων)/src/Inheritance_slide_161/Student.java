package Inheritance_slide_161;

public class Student extends Human {
   private int Am;

    public void setAm(int am) {
        Am = am;
    }

    public int getAm() {
        return Am;
    }
    public void Istudy(){
        System.out.println("Hello I am a student and i study for my exams!!");
    }
}
