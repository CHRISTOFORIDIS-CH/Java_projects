package Method_Overloading_slide_110;

public class OverloadedMethod { //θελω να εχω πολλες συναρτησεις με τις οποιες θα μπορω να προσθετω απο 2 εως 5 αριθμους
    public int addNums(int a,int b){
        return a + b;
    }
    public int addNums(int a,int b,int c){
        return a + b + c;
    }
    public int addNums(int a,int b,int c, int d){
        return a + b + c +d;
    }
    public int addNums(int a,int b,int c,int d,int e){
        return a + b + c + d + e;
    }
    // το ιδιο θα μπορουσε να γινει αν ηθελα να αλλαζει η ακριβεια δηλαδη να εχω και δεκαδικα δλδ
    public float addNums(float a,float b){
        return a + b;
    }
    public double addNums(double a,double b){
        return a + b;
    }
    /*
    *Δηλαδη Method Overload μπορω να κανω ειτε αλλαζοντας τον αριθμο των παραμετρων
    * ειτε αλλαζοντας τον τυπο των παραμετρων
     */
}
