package Constructors_slide_111;

import java.util.*;

public class ConstructorExample { // καταγραφη ανθρωπων σε μια λιστα ειναι σιγουρα απαραιτητα η ηλικια και το Ονομα
    public static void main(String args[]){
        List<Human> HumanList = new ArrayList<Human>();
        Human newHuman = new Human(19,"Charis");
     HumanList.add(newHuman);
    }
}
