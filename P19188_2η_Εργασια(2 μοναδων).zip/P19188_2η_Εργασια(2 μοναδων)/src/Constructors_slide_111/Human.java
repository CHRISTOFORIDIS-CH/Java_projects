package Constructors_slide_111;

public class Human {
    private int age;
    private String name;
    public Human(int age,String name) { // για να υπαρξει καποιος ανρθωπος πρεπει σιγουρα να εχει ονομα και ηλικια
        this.age = age;
        this.name = name;
    }
}
