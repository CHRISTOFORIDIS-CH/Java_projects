package TopLevelClass_vs_NestedClass_Note_slides_40_41;

public class TopLevelClass {
    static int a = 10;
    static int b = 20;
    int c = 30;
    void printSomething(){
        System.out.println("Hello I am an instance of TopLevelClass");
    }
    //public InnerClass{} δεν με αφηνει και μου προτεινει να το βαλω σε αλλο αρχειο,αφου public class μπορω να εχω μονο μια σε ενα αρχειο
    static class StaticNestedClass{
        public void addNums(){
            System.out.println(a+b);
            //System.out.println(a+c); // δεν μπορει να αναγνωρισει το c γτ ειναι non-static και αυτη αναγνωριζει μονο τα static της topclass
        }
    }
    class InnerClass{
void printSomething_2(){
    System.out.println("Hello i am an instance of Innerclass");
}
    }
    public static void main(String args[]){
        TopLevelClass obj = new TopLevelClass();
        obj.printSomething();
    }
}
