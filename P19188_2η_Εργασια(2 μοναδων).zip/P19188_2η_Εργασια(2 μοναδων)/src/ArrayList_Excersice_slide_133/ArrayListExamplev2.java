package ArrayList_Excersice_slide_133;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListExamplev2 {
    public static void main(String args[]){
    ArrayList<Integer> arrList1 = new ArrayList();
    //εισαγωγη με i
    for(int i = 0; i <= 10; i++) {
        arrList1.add(i); // βαζω τους αριθμους απο 1 εως 10
    }
        ListIterator<Integer> iterator = arrList1.listIterator();
    while(iterator.hasNext()){
        System.out.println(iterator.next()); // εκτυπωση
    }
    }
    /*
    *συνδυαζω αυτο με τα παραδειγματα του java_ArrayList_slide_127
     */
}
