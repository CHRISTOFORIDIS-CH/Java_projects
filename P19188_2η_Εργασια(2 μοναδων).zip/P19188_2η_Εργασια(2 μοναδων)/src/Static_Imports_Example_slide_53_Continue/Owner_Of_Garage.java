package Static_Imports_Example_slide_53_Continue;
import static Static_Imports_Example_slide_53.car_garage.carsnNum;
public class Owner_Of_Garage {
    public static void main(String args[]) {
            System.out.println("I want to add 5 cars to my garage");
            carsnNum = carsnNum + 5;    //πειρα με static import τον αριθμο αυτκινητων απο το garage και σαν ιδιοκτητης προσθεσα 5
    }

}
