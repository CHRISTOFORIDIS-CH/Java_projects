package This_And_Super_slide_104;

public class SuperClass {
    int a = 10 ;
    int b = 20;
}
