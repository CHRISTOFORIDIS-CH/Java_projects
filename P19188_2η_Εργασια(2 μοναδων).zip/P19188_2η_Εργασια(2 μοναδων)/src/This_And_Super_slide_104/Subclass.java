package This_And_Super_slide_104;

public class Subclass extends SuperClass {
    int num1 = 10;
    int num2 = 15;
        public void addNums() {
            System.out.println(this.num1 + this.num2);
        }
        public void addSuperNums(){
            System.out.println(super.a +super.b); // προσθετει τις μεταβλητες της Superclass
        }
/*
*με τα this μπορω να χρησιμοποιησω μεταβλητες,συναρτησεις της κλασσης στην οποια βρισκεται μεσα η συναρτηση χωρις να κανω instanciate καποιο object
* ενω με το super μπορω να χρησιμοποιησω μεταβλητες κλπ της κλασσης <<γονιος>>
 */

}
