package Vairable_Usages_From_Anonymous_Classes_slide_201;

public class NewClass {
    String s = "Charis";
    final String s2 = "Giorgos";
    public void printS(String s){
        System.out.println("The value of s is: "+s);
    }
}
