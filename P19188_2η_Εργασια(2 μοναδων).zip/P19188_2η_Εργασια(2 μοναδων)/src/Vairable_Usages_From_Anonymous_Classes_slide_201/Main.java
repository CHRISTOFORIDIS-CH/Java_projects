package Vairable_Usages_From_Anonymous_Classes_slide_201;

public class Main {
    public static void main(String args[]){

    }
}
