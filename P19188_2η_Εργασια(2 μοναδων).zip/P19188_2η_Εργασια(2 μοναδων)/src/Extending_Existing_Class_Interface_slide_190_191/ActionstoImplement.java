package Extending_Existing_Class_Interface_slide_190_191;

public interface ActionstoImplement {
    void printSomething();
}
