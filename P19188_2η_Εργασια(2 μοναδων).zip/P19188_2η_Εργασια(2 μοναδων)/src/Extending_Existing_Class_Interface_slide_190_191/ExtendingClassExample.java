package Extending_Existing_Class_Interface_slide_190_191;

public class ExtendingClassExample {
    public static void main(String args[]){
        new superClass("charis"){
            String s2;
            void superClass(String s){
                s2 =this.s; // δευτερο constructor(extra)
            }
            public void print(){
                System.out.println("Hello I am anonymous now!");
            }
        }.print();
        new ActionstoImplement(){
           public void printSomething(){
                System.out.println("Hello World");
            }
        }.printSomething();

    }
}
