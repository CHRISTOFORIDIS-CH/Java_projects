package Extending_Existing_Class_Interface_slide_190_191;

public class superClass {
    String s;

    public superClass(String s) { // constructor
        this.s = s;
    }
    public void print(){
        System.out.println("Hello");
    }
}
