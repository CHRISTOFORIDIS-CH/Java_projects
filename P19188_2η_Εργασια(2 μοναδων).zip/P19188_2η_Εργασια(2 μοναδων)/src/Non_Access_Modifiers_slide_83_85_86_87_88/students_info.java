package Non_Access_Modifiers_slide_83_85_86_87_88;

interface students_info {     //υποχρεώνει την κλάση που θα το κάνει impliment να δώσει όλα τα απαραίτητα στοιχεια
     public String give_address();
     public String give_Name();
     public int give_age();
}
