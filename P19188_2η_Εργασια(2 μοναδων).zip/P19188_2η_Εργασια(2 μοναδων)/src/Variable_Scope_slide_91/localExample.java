package Variable_Scope_slide_91;

public class localExample {
     int example() {
         int sum = 0;
         for (int i = 0; i <= 10; i++){
             int a = 0;
             sum++;
         }
         return sum; //return a; ή return a ειναι error,αφου ο compiler δεν τα αναγνωριζει

     }
    /*ενω μπορω να πω return sum δεν μπορω να πω return i ή return a αφου το i και το a ειναι
    *ειναι local μεταβλητες και συνεπως ισχυεουν μονο μεσα στις {} που επροκειμενου ειναι το
    * while το sum σε αντιθεση νε μεν αλλαζει τιμη στο while αλλα ειναι ορισμενο μεσα στις {}
    * του example και συνεπως αναγνωριζεται
     */
}
