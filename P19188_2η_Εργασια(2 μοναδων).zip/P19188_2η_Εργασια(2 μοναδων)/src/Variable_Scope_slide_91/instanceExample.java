package Variable_Scope_slide_91;

public class instanceExample {
    private int StudentsGrade1;
    private int StudentGrade2;

    public void setStudentGrade2(int studentGrade2) {
        StudentGrade2 = studentGrade2;
    }

    public void setStudentsGrade1(int studentsGrade1) {
        StudentsGrade1 = studentsGrade1;
    }

    public int getStudentGrade2() {
        return StudentGrade2;
    }

    public int getStudentsGrade1() {
        return StudentsGrade1;
    }

    public float calculateMO(int a, int b){
        return (a+b)/2;
    }
}
