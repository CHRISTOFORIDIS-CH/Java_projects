package Variable_Scope_slide_91;

public class MainTest {
    public static void main(String args[]){
        //test των Instance
        instanceExample newStudent = new instanceExample();
        newStudent.setStudentsGrade1(10);
        newStudent.setStudentGrade2(10);
        newStudent.calculateMO(newStudent.getStudentsGrade1(),newStudent.getStudentGrade2());
        //αλλος μαθητης
        instanceExample newStudent2 = new instanceExample();
        newStudent2.setStudentsGrade1(20);
        newStudent2.setStudentGrade2(20);
        newStudent2.calculateMO(newStudent2.getStudentsGrade1(),newStudent2.getStudentGrade2());
        /*
        *οπως βλεπω το καθε αντικείμενο εχει δικά του Grade1 και Grade2 καθως επισης και η μέθοδος χρησιμοποιείται απο ολα τα αντικειμενα(μαθητες)
        * ΠΟΡΣΟΧΗ!! Δεν γινεται να ειναι static
         */
        //test ClassVairable
        System.out.println(classVairableExample.var1);
        /*
        *επειδη ειναι classVairable(static μεσα στην class) ειναι ιδια για ολα τα αντικείμενα δεν εχει το καθενα τη δικια
        * του και την καλο παντα με το <<ονομα της κλασσης.ονομα μεταβλητης>>(best practise)
         */
    }
}
