package Variable_Scope_slide_91;

public class classVairableExample {
    static String var1 = "I am a variable of classVairableExample class";
}
