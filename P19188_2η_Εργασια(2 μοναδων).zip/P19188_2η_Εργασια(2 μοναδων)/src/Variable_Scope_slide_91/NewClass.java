package Variable_Scope_slide_91;

public class NewClass {
    String s = "charis";
    final String s2 = "Giorgos";
    public void printS(){
        System.out.println("The value of s is "+s);
    }
}
