package Initializer_Block_slide_115;

public class InitializerBlockExample {
//εστω κλασση αυτοκινητων
    int horsePower;
    int enginePower;
    String CarModel;
    {
        horsePower = 300;
        enginePower = 2500;
        CarModel = "Porsche";
    }
    public static void main(String args){
        InitializerBlockExample objCar = new InitializerBlockExample();
        System.out.println("The horse power of the car is: "+ objCar.horsePower);
        System.out.println("The engine power of the car is: "+ objCar.enginePower);
        System.out.println("The model of the car is: "+objCar.CarModel);
    }
    /*
    *Οι τιμες στις μεταβλητες δωθηκαν στο initializer block γιατι αλλιως δεν θα μπορουσαν να εκτυπωθουν στη main συνεπως επρεπαι
    * οποσδηποτε να δωθουν
     */
}
