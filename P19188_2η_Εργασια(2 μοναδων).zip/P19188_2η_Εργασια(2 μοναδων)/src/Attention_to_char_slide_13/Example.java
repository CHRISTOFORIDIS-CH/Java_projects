package Attention_to_char_slide_13;

public class Example {
        char a = 'a';
        //char b = "b"; //required type:char provided:String (error)
        String c = "c";
        //String d = 'd'; // required type:String provided:char (error)
        char[] Carray = {'a','b','c','d'};
        //char[] Carray_2 = {"a","b","c","d"}; // required type:char provided:String (error)
        String[] Sarray = {"a","b","c","d"};
        //String[] Sarray_2 ={'a','b','c','d'}; // required type:String provided:char (error)
    }
/*παρατηρω και διαπιστωνω οτι οταν δηλωνω char πρεπει το περιεχομενο να ειναι
 *εντος μονων ('...') αντιθετα οταν δηλωνω String πρεπει να ειναι εντος διπλων
 * ("...") αυτο ισχυει και για τους πινακες των char και String
 */

